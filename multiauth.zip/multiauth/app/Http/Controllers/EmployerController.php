<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Employers;

use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Hash;

class EmployerController extends Controller
{
    public function index()
    {
        return view('employers.register');
    }


    public function register(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:candidates',
            'password' => 'required|string|min:8',
            'user_role' => 'required|string|in:owner,staff',
        ]);
    
        // Hash the password
        $hashedPassword = Hash::make($request->password);
    
        // Create and save the new candidate
        $candidate = Employers::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $hashedPassword,
            'user_role' => $request->user_role,
        ]);
    
        // Redirect after successful creation with a success message
        return redirect()->route('employers.index')->with('success', 'Employers registered successfully');
    }


public function showLoginForm()
{
     return view('employers.login');
}


    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');
    
        if (Auth::guard('employer')->attempt($credentials)) {
            return redirect()->route('employers.dashboard');
        }
    
        return redirect()->back()->withInput()->withErrors(['email' => 'Invalid credentials']);
    }


    public function dashboard()
    {
        if (Auth::guard('employer')->check()) {
            $user = Auth::guard('employer')->user();
            return view('employers.dashboard', compact('user'));
        } else {
            return redirect()->route('employers.login')->with('error', 'You must be logged in to access the dashboard.');
        }
    }
    
    public function logout(Request $request)
    {
        Auth::guard('employer')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('employers.login');
    }
    


}
