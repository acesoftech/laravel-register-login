@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        @if(Auth::guard('employer')->check())
                            <p>Welcome, {{ Auth::guard('employer')->user()->name }}</p>
                            <p>Your role: {{ Auth::guard('employer')->user()->user_role }}</p>
                            <form action="{{ route('employers.logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="btn btn-danger">Logout</button>
                            </form>
                            @else
                            <p>You are not logged in</p>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
