<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Candidates;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Hash;

class CandidateController extends Controller
{
    
    public function index()
    {
        return view('candidates.register');
    }

    public function register(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:candidates',
            'password' => 'required|string|min:8',
            'user_role' => 'required|string|in:developer,designer',
        ]);
    
        // Hash the password
        $hashedPassword = Hash::make($request->password);
    
        // Create and save the new candidate
        $candidate = Candidates::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $hashedPassword,
            'user_role' => $request->user_role,
        ]);
    
        // Redirect after successful creation with a success message
        return redirect()->route('candidates.index')->with('success', 'Candidate registered successfully');
    }


    public function showLoginForm()
    {
         return view('candidates.login');
    }
    
    
        public function login(Request $request)
        {
            $credentials = $request->only('email', 'password');
        
            if (Auth::guard('candidate')->attempt($credentials)) {
                return redirect()->route('candidates.dashboard');
            }
        
            return redirect()->back()->withInput()->withErrors(['email' => 'Invalid credentials']);
        }
    
    
        public function dashboard()
        {
            if (Auth::guard('candidate')->check()) {
                $user = Auth::guard('candidate')->user();
                return view('candidates.dashboard', compact('user'));
            } else {
                return redirect()->route('candidates.login')->with('error', 'You must be logged in to access the dashboard.');
            }
        }   

        public function logout(Request $request)
        {
            Auth::guard('candidate')->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return redirect()->route('candidates.login');
        }
        

}
