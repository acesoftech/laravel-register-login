<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CandidateController;
use App\Http\Controllers\EmployerController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::post('/candidates/register', [CandidateController::class, 'register'])->name('candidates.register');

Route::get('/candidates', [CandidateController::class, 'index'])->name('candidates.index');

// employers  routes


// Employer authentication routes
Route::get('/employers/login', [EmployerController::class, 'showLoginForm'])->name('employers.login');
Route::post('/employers/login', [EmployerController::class, 'login'])->name('employers.login.submit');


//  EMployers

Route::get('/employers', [EmployerController::class, 'index'])->name('employers.index');

Route::post('/employers/register', [EmployerController::class, 'register'])->name('employers.register');

Route::group(['middleware' => 'auth:employer'], function () {
    // Dashboard route for employers
    Route::get('/employers/dashboard', [EmployerController::class, 'dashboard'])->name('employers.dashboard');
    // Logout route for employers
    Route::post('/employers/logout', [EmployerController::class, 'logout'])->name('employers.logout');
});




Route::get('/candidates/login', [CandidateController::class, 'showLoginForm'])->name('candidates.login');
Route::post('/candidates/login', [CandidateController::class, 'login'])->name('candidates.login.submit');

Route::group(['middleware' => 'auth:candidate'], function () {
    // Dashboard route for employers
    Route::get('/candidates/dashboard', [CandidateController::class, 'dashboard'])->name('candidates.dashboard');
    // Logout route for employers
    Route::post('/candidates/logout', [CandidateController::class, 'logout'])->name('candidates.logout');
});