

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Candidates Dashboard</div>

                    <div class="card-body">
                        <?php if(Auth::guard('candidate')->check()): ?>
                            <p>Welcome, <?php echo e(Auth::guard('candidate')->user()->name); ?></p>
                            <p>Your role: <?php echo e(Auth::guard('candidate')->user()->user_role); ?></p>
                      
                            <form action="<?php echo e(route('candidates.logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Logout</button>
                            </form>
                            <?php else: ?>
                            <p>You are not logged in</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\multiauth\resources\views/candidates/dashboard.blade.php ENDPATH**/ ?>